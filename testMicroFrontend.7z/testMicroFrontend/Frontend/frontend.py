from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def hello_world():
    return render_template('index.html',
                            b1d1="http://localhost:5002/",
                            b1d2="http://localhost:5002/secondoEndpoint",
                            b2d1="http://localhost:5003/",
                            b2d2="http://localhost:5003/secondoEndpoint")
